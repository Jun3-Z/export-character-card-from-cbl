console.log('popup.js v4.6 loaded');

// ==================== 从页面提取数据的函数（注入到目标页面执行） ====================
function extractFromPage() {
  // ---------- 清理多余空白，但保留段落换行 ----------
  function cleanText(text) {
    return text
      .replace(/[ \t]+/g, ' ')      // 多个空格/制表符 → 单个空格
      .replace(/\n\s*\n+/g, '\n')   // 多个空行（可能含空格） → 单个换行
      .replace(/^\s+|\s+$/g, '');   // 去除开头结尾空白
  }

  // ---------- 辅助函数：从多个选择器获取第一个非空文本 ----------
  function getText(selectors) {
    for (let sel of selectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim()) {
        return el.textContent.trim();
      }
    }
    return '';
  }

  // ---------- 辅助函数：从多个选择器获取第一个有效图片 src（优先 srcset 中最大尺寸） ----------
  function getImageSrc(selectors) {
    for (let sel of selectors) {
      const el = document.querySelector(sel);
      if (!el) continue;

      // 优先从 srcset 中挑选最大尺寸
      if (el.srcset) {
        let bestUrl = '';
        let bestWidth = 0;
        const entries = el.srcset.split(',').map(s => s.trim()).filter(Boolean);

        for (const entry of entries) {
          const parts = entry.split(/\s+/);
          const candidateUrl = parts[0];
          let width = 0;

          if (parts[1]) {
            const m = parts[1].match(/^(\d+(?:\.\d+)?)w$/);
            if (m) width = parseFloat(m[1]);
          }

          if (candidateUrl && candidateUrl.startsWith('http') && width >= bestWidth) {
            bestUrl = candidateUrl;
            bestWidth = width;
          }
        }

        if (bestUrl) return bestUrl;
      }

      if (el.src && el.src.startsWith('http')) {
        return el.src;
      }
    }
    return '';
  }

  // ---------- 改进版：根据标题文本获取其后所有兄弟元素的文本（直到遇到下一个标题） ----------
  function getSectionByHeading(headingText) {
    const headings = document.querySelectorAll(
      'h1, h2, h3, h4, h5, h6, [class*="title"], [class*="heading"], [class*="label"]'
    );

    for (let heading of headings) {
      if (heading.textContent.trim().toLowerCase() === headingText.toLowerCase()) {
        const parent = heading.parentElement;
        if (!parent) continue;

        let textParts = [];
        let current = heading.nextElementSibling;

        while (current) {
          const tag = current.tagName.toLowerCase();
          const classAttr = current.className || '';
          const isHeading =
            /^h[1-6]$/.test(tag) ||
            /title|heading|label/i.test(classAttr);

          if (isHeading && current.textContent.trim()) {
            break;
          }

          const currentText = current.textContent.trim();
          if (currentText) {
            textParts.push(currentText);
          }

          current = current.nextElementSibling;
        }

        if (textParts.length > 0) {
          return textParts.join('\n').trim();
        }

        const parentText = parent.textContent.trim();
        const titleLength = heading.textContent.trim().length;
        return parentText.slice(titleLength).trim();
      }
    }
    return '';
  }

  // ---------- 新增：根据 heading 文本获取紧随其后的第一个非空文本（用于 Category / Fandom） ----------
  function getFirstTextAfterHeading(headingText) {
    const headings = document.querySelectorAll(
      'p.heading, [class="heading"], h1, h2, h3, h4, h5, h6'
    );

    for (const heading of headings) {
      if (heading.textContent.trim().toLowerCase() !== headingText.toLowerCase()) continue;

      let current = heading.nextElementSibling;

      while (current) {
        const tag = current.tagName.toLowerCase();
        const classAttr = current.className || '';
        const isHeading =
          /^h[1-6]$/.test(tag) ||
          /heading|label/i.test(classAttr);

        if (isHeading && current.textContent.trim()) {
          break;
        }

        const currentText = current.textContent.trim();
        if (currentText) {
          return currentText;
        }

        current = current.nextElementSibling;
      }
    }

    return '';
  }

  // ========== 提取姓名 ==========
  let name = '';
  const nameSelectors = [
    '[data-testid="character-name"]',
    '[class*="character-name"]',
    '[class*="char-name"]',
    '.name'
  ];
  name = getText(nameSelectors);

  if (!name) {
    const h1 = document.querySelector('h1');
    if (h1) {
      let rawText = h1.textContent.trim();
      rawText = rawText.replace(/^Chat with\s+/i, '');
      rawText = rawText.replace(/\s+on\s+Character\s+AI\s*$/i, '');
      name = rawText.trim();
    }
  }

  if (!name) {
    const title = document.title;
    const match = title.match(/(.+?)\s*[-|]\s*Character\.AI/i);
    if (match) {
      name = match[1].trim();
    }
  }

  // ========== 提取头像 ==========
  const avatarSelectors = [
    'img[src*="avatars/uploaded"]',
    'img[src*="/avatars/"]',
    'img[class*="avatar"]',
    'img[data-testid="avatar"]'
  ];
  const avatar = getImageSrc(avatarSelectors);

  // ========== 提取副标题 ==========
  const taglineSelectors = [
    '[data-testid="tagline"]',
    '[class*="tagline"]',
    '[class*="subtitle"]',
    '[class*="sub-title"]'
  ];
  const tagline = getText(taglineSelectors);

  // ========== 提取 Category ==========
  const category = getFirstTextAfterHeading('Category');

  // ========== 提取 Fandom ==========
  const fandom = getFirstTextAfterHeading('Fandom');

  // ========== 提取 NSFW 标识 ==========
  let nsfw = '';
  const nsfwSpans = document.querySelectorAll('span');

  for (const span of nsfwSpans) {
    const text = span.textContent.trim();

    // 精确匹配 <span>🔞 NSFW</span>
    // 同时兼容没有 emoji 的 <span>NSFW</span>
    if (/^🔞\s*NSFW$/i.test(text) || /^NSFW$/i.test(text)) {
      nsfw = text;
      break;
    }
  }

  // ========== 提取 Description 和 Greeting ==========
  let description = getText([
    '[data-testid="description"]',
    '[class*="description"]',
    '[class*="bio"]'
  ]);
  let greeting = getText([
    '[data-testid="greeting"]',
    '[class*="greeting"]',
    '[class*="welcome"]',
    '[class*="intro"]'
  ]);

  if (!description) {
    description = getSectionByHeading('Description');
  }
  if (!greeting) {
    greeting = getSectionByHeading('Greeting');
  }

  // 清理 description 和 greeting 中的多余空白
  description = cleanText(description);
  greeting = cleanText(greeting);

  // ========== 返回结果 ==========
  return {
    name: name,
    tagline: tagline,
    category: category,
    fandom: fandom,
    nsfw: nsfw,
    avatar: avatar,
    description: description,
    greeting: greeting
  };
}

// ==================== Popup 脚本主逻辑 ====================

let currentData = {
  name: '',
  tagline: '',
  category: '',
  fandom: '',
  nsfw: '',
  avatar: '',
  description: '',
  greeting: ''
};

const statusEl = document.getElementById('status');
const resultEl = document.getElementById('result');
const avatarImg = document.getElementById('avatar');
const avatarPlaceholder = document.getElementById('avatar-placeholder');
const nameEl = document.getElementById('name');
const taglineEl = document.getElementById('tagline');
const categoryFieldEl = document.getElementById('category-field');
const categoryEl = document.getElementById('category');
const fandomFieldEl = document.getElementById('fandom-field');
const fandomEl = document.getElementById('fandom');
const nsfwFieldEl = document.getElementById('nsfw-field');
const nsfwEl = document.getElementById('nsfw');
const descriptionEl = document.getElementById('description');
const greetingEl = document.getElementById('greeting');
const copyAllBtn = document.getElementById('copy-all');
const copyAvatarBtn = document.getElementById('copy-avatar');
const exportJsonBtn = document.getElementById('export-json');
const exportHtmlBtn = document.getElementById('export-html');
const refreshBtn = document.getElementById('refresh');

// ==================== 通用工具函数 ====================

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// 让每个段落之间增加一个空行（用于 HTML 导出展示）
function addParagraphSpacing(text) {
  return String(text || '')
    .replace(/\r\n?/g, '\n')   // 统一换行符为 \n
    .replace(/\n+/g, '\n\n');  // 每段之间保持一个空行
}

// ==================== 导出 HTML 的字体设置（可自行修改） ====================
const EXPORT_HTML_FONT_FAMILY =
  '"Times New Roman", "SimSun", "宋体", "Noto Serif CJK SC", serif';

// 是否在导出文件名中移除 emoji
const REMOVE_EMOJI_IN_FILENAME = true;

// 移除常见 emoji
function removeEmoji(input) {
  return String(input || '')
    .replace(
      /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}\u{20E3}\u{1F1E6}-\u{1F1FF}\u{1F3FB}-\u{1F3FF}]/gu,
      ''
    )
    .replace(/\s+/g, ' ')
    .trim();
}

// 清理文件名中的非法字符
function sanitizeFileName(input) {
  let result = String(input || '')
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (REMOVE_EMOJI_IN_FILENAME) {
    result = removeEmoji(result);
  }

  return result;
}

// 生成导出文件名：姓名 - 副标题.ext
function buildExportFileName(extension) {
  const safeName = sanitizeFileName(currentData.name) || 'character';
  const safeTagline = sanitizeFileName(currentData.tagline);

  let base = safeTagline ? `${safeName} - ${safeTagline}` : safeName;

  const maxLength = 120;
  if (Array.from(base).length > maxLength) {
    base = Array.from(base).slice(0, maxLength).join('').trim();
  }

  return `${base}.${extension}`;
}

// 根据头像 URL 生成多个候选地址
function buildAvatarCandidates(url) {
  const candidates = [url];

  try {
    const u = new URL(url);
    const path = u.pathname;
    const sizeMatch = path.match(/^\/i\/(\d+)\/(.+)$/);

    const clone = (newPath, clearSearch = false) => {
      const copy = new URL(u);
      copy.pathname = newPath;
      if (clearSearch) copy.search = '';
      return copy.toString();
    };

    if (sizeMatch) {
      const rest = sizeMatch[2];

      for (const size of [400, 600, 800, 1024, 1600]) {
        candidates.push(clone(`/i/${size}/${rest}`));
      }

      candidates.push(clone(`/${rest}`));
      candidates.push(clone(`/${rest}`, true));
    }
  } catch (err) {
    // 忽略 URL 解析错误
  }

  return [...new Set(candidates)];
}

function preferFormat(a, b) {
  const rank = {
    'image/webp': 4,
    'image/png': 4,
    'image/jpeg': 4,
    'image/gif': 2,
    'image/avif': 2,
    'image/svg+xml': 1
  };
  return (rank[a] || 0) > (rank[b] || 0);
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('FileReader 读取失败'));
    reader.readAsDataURL(blob);
  });
}

// 读取图片真实尺寸
async function getBlobDimensions(blob) {
  try {
    const bitmap = await createImageBitmap(blob);
    const width = bitmap.width;
    const height = bitmap.height;
    bitmap.close();
    return { width, height };
  } catch (err) {
    const objectUrl = URL.createObjectURL(blob);
    try {
      return await new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
        img.onerror = () => resolve({ width: 0, height: 0 });
        img.src = objectUrl;
      });
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  }
}

// 带超时的 fetch
async function fetchWithTimeout(url, options, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// 从多个候选地址中下载头像，并挑选最大尺寸的一张
async function downloadBestAvatar(url) {
  if (!url) return { dataUrl: '', format: '', width: 0, height: 0 };

  const candidates = buildAvatarCandidates(url);
  let best = { dataUrl: '', format: '', width: 0, height: 0, pixels: 0 };

  for (const candidate of candidates) {
    try {
      const response = await fetchWithTimeout(
        candidate,
        {
          method: 'GET',
          cache: 'force-cache',
          referrerPolicy: 'no-referrer',
          headers: {
            Accept: 'image/webp,image/png,image/jpeg,image/*;q=0.8,*/*;q=0.5'
          }
        },
        8000
      );

      if (!response.ok) continue;

      const blob = await response.blob();
      if (!blob.type || !blob.type.startsWith('image/')) continue;

      const dims = await getBlobDimensions(blob);
      if (!dims.width || !dims.height) continue;

      const pixels = dims.width * dims.height;
      const format = blob.type;

      if (pixels > best.pixels || (pixels === best.pixels && preferFormat(format, best.format))) {
        const dataUrl = await blobToDataUrl(blob);
        best = { dataUrl, format, width: dims.width, height: dims.height, pixels };
      }

      if (dims.width >= 1024 && dims.height >= 1024) break;
    } catch (err) {
      // 忽略单个候选地址的失败，继续尝试下一个
    }
  }

  return best;
}

// 获取用于导出的头像（优先高清 Base64）
async function getAvatarForExport() {
  if (!currentData.avatar) {
    return { src: '', highRes: false, width: 0, height: 0 };
  }

  const best = await downloadBestAvatar(currentData.avatar);

  if (best.dataUrl) {
    return {
      src: best.dataUrl,
      highRes: true,
      width: best.width,
      height: best.height
    };
  }

  return {
    src: currentData.avatar || '',
    highRes: false,
    width: 0,
    height: 0
  };
}

function showStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.className = isError ? 'error' : '';
  statusEl.style.display = 'block';
  setTimeout(() => {
    statusEl.style.display = 'none';
  }, 3000);
}

function updateUI(data) {
  currentData = data;
  nameEl.textContent = data.name || '未找到姓名';
  taglineEl.textContent = data.tagline || '';

  // Category：页面存在时才显示
  if (data.category) {
    categoryFieldEl.style.display = 'block';
    categoryEl.textContent = data.category;
  } else {
    categoryFieldEl.style.display = 'none';
    categoryEl.textContent = '';
  }

  // Fandom：页面存在时才显示
  if (data.fandom) {
    fandomFieldEl.style.display = 'block';
    fandomEl.textContent = data.fandom;
  } else {
    fandomFieldEl.style.display = 'none';
    fandomEl.textContent = '';
  }

  // NSFW：页面存在时才显示
  if (data.nsfw) {
    nsfwFieldEl.style.display = 'block';
    nsfwEl.textContent = data.nsfw;
  } else {
    nsfwFieldEl.style.display = 'none';
    nsfwEl.textContent = '';
  }

  descriptionEl.textContent = data.description || '（无）';
  greetingEl.textContent = data.greeting || '（无）';

  if (data.avatar && data.avatar.startsWith('http')) {
    avatarImg.onerror = () => {
      avatarImg.style.display = 'none';
      avatarPlaceholder.style.display = 'block';
    };
    avatarImg.onload = () => {
      avatarImg.style.display = 'block';
      avatarPlaceholder.style.display = 'none';
    };
    avatarImg.src = data.avatar;
  } else {
    avatarImg.style.display = 'none';
    avatarPlaceholder.style.display = 'block';
  }

  resultEl.style.display = 'block';
}

// 判断当前标签页是否可注入脚本（只有 http/https 网页可以）
function isInjectableUrl(url) {
  if (!url) return false;
  return url.startsWith('http://') || url.startsWith('https://');
}

async function extractFromCurrentTab() {
  try {
    showStatus('正在提取...', false);

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      showStatus('无法获取当前标签页', true);
      return;
    }

    const url = tab.url || tab.pendingUrl || '';

    // 关键：内部页面（chrome://、edge://、about: 等）不能注入脚本
    if (!isInjectableUrl(url)) {
      showStatus('当前页面无法提取，请切换到 caibotlist.com 或 Character.AI 角色页', true);
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractFromPage
    });

    if (results && results[0] && results[0].result) {
      updateUI(results[0].result);
      showStatus('提取成功', false);
    } else {
      showStatus('未提取到数据，请确认页面是 caibotlist.com 或 Character.AI 角色页', true);
    }
  } catch (error) {
    console.warn('提取失败:', error);
    showStatus('提取失败: ' + (error.message || error), true);
  }
}

// ==================== 事件绑定 ====================

document.addEventListener('DOMContentLoaded', extractFromCurrentTab);

refreshBtn.addEventListener('click', extractFromCurrentTab);

copyAllBtn.addEventListener('click', async () => {
  const lines = [
    `姓名: ${currentData.name || '未找到'}`,
    `副标题: ${currentData.tagline || ''}`
  ];

  if (currentData.category) {
    lines.push(`Category: ${currentData.category}`);
  }

  if (currentData.fandom) {
    lines.push(`Fandom: ${currentData.fandom}`);
  }

  if (currentData.nsfw) {
    lines.push(`NSFW: ${currentData.nsfw}`);
  }

  lines.push(
    `头像URL: ${currentData.avatar || '无'}`,
    `Description: ${currentData.description || ''}`,
    `Greeting: ${currentData.greeting || ''}`
  );

  const text = lines.join('\n');

  try {
    await navigator.clipboard.writeText(text);
    showStatus('已复制全部信息', false);
  } catch (err) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    showStatus('已复制（降级方案）', false);
  }
});

copyAvatarBtn.addEventListener('click', async () => {
  if (currentData.avatar) {
    try {
      await navigator.clipboard.writeText(currentData.avatar);
      showStatus('头像URL已复制', false);
    } catch (err) {
      const textarea = document.createElement('textarea');
      textarea.value = currentData.avatar;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      showStatus('头像URL已复制（降级方案）', false);
    }
  } else {
    showStatus('没有头像URL可复制', true);
  }
});

// ========== 导出 JSON ==========
exportJsonBtn.addEventListener('click', async () => {
  exportJsonBtn.disabled = true;
  exportJsonBtn.textContent = '正在导出...';

  let avatarData = currentData.avatar || '';

  if (avatarData) {
    const result = await getAvatarForExport();
    avatarData = result.src;

    if (result.highRes) {
      showStatus(`已获取头像 Base64 (${result.width}×${result.height})`, false);
    } else {
      showStatus('头像 Base64 获取失败，使用原始 URL', true);
    }
  }

  const jsonObject = {
    name: currentData.name || '',
    tagline: currentData.tagline || '',
    // 以下字段仅在页面存在时才会写入 JSON
    ...(currentData.category ? { category: currentData.category } : {}),
    ...(currentData.fandom ? { fandom: currentData.fandom } : {}),
    ...(currentData.nsfw ? { nsfw: currentData.nsfw } : {}),
    description: currentData.description || '',
    greeting: currentData.greeting || '',
    avatar: avatarData
  };

  const jsonString = JSON.stringify(jsonObject, null, 2);

  const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = buildExportFileName('json');
  a.click();
  URL.revokeObjectURL(url);

  exportJsonBtn.disabled = false;
  exportJsonBtn.textContent = '导出JSON';
  showStatus('JSON 文件已导出', false);
});

// ========== 导出 HTML ==========
exportHtmlBtn.addEventListener('click', async () => {
  let avatarSrc = currentData.avatar || '';
  let highRes = false;

  if (avatarSrc) {
    exportHtmlBtn.disabled = true;
    exportHtmlBtn.textContent = '正在获取高清头像...';

    try {
      const best = await downloadBestAvatar(avatarSrc);

      if (best.dataUrl) {
        avatarSrc = best.dataUrl;
        highRes = true;
        showStatus(`已获取高清头像 (${best.width}×${best.height})`, false);
      } else {
        avatarSrc = currentData.avatar || '';
        showStatus('高清头像获取失败，使用原 URL', true);
      }
    } catch (err) {
      console.warn('高清头像获取失败:', err);
      avatarSrc = currentData.avatar || '';
      showStatus('高清头像获取失败，使用原 URL', true);
    } finally {
      exportHtmlBtn.disabled = false;
      exportHtmlBtn.textContent = '导出HTML';
    }
  }

  const safeName = escapeHtml(currentData.name || '未知姓名');
  const safeTagline = escapeHtml(currentData.tagline || '');
  const safeCategory = escapeHtml(currentData.category || '');
  const safeFandom = escapeHtml(currentData.fandom || '');
  const safeNsfw = escapeHtml(currentData.nsfw || '');
  const safeDescription = escapeHtml(addParagraphSpacing(currentData.description || '（无）'));
  const safeGreeting = escapeHtml(addParagraphSpacing(currentData.greeting || '（无）'));
  const safeAvatar = escapeHtml(avatarSrc);

  const avatarHtml = safeAvatar
    ? `<img src="${safeAvatar}" alt="头像">`
    : '<p>无头像</p>';

  // 以下区块仅在页面存在对应内容时才写入导出 HTML
  const categoryHtml = safeCategory
    ? `<div class="info">
        <h3>Category</h3>
        <p>${safeCategory}</p>
      </div>`
    : '';

  const fandomHtml = safeFandom
    ? `<div class="info">
        <h3>Fandom</h3>
        <p>${safeFandom}</p>
      </div>`
    : '';

  const nsfwHtml = safeNsfw
    ? `<div class="info">
        <h3>NSFW</h3>
        <p>${safeNsfw}</p>
      </div>`
    : '';

  const htmlContent = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>${safeName} - Character AI Info</title>
    <style>
        body { font-family: ${EXPORT_HTML_FONT_FAMILY}; max-width: 600px; margin: 20px auto; padding: 20px; }
        .avatar { text-align: center; margin-bottom: 20px; }
        .avatar img { width: 150px; height: 150px; border-radius: 50%; object-fit: cover; }
        h1 { text-align: center; }
        .info { margin-bottom: 15px; }
        .info h3 { border-bottom: 1px solid #eee; padding-bottom: 5px; }
        .info p { white-space: pre-wrap; }
    </style>
</head>
<body>
    <div class="avatar">
        ${avatarHtml}
    </div>
    <h1>${safeName}</h1>
    ${safeTagline ? `<p style="text-align:center;color:#666;">${safeTagline}</p>` : ''}
    ${categoryHtml}
    ${fandomHtml}
    ${nsfwHtml}
    <div class="info">
        <h3>Description</h3>
        <p>${safeDescription}</p>
    </div>
    <div class="info">
        <h3>Greeting</h3>
        <p>${safeGreeting}</p>
    </div>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = buildExportFileName('html');
  a.click();
  URL.revokeObjectURL(url);

  showStatus(
    highRes ? 'HTML 已导出（含高清头像）' : 'HTML 文件已导出',
    false
  );
});